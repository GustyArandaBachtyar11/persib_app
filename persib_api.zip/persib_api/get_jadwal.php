<?php
// Menghubungkan file koneksi ke database
include "koneksi.php";

// Membuat query SQL untuk mengambil seluruh data dari tabel jadwal
$query = "SELECT * FROM jadwal";

// Menjalankan query ke database menggunakan koneksi yang tersedia
$result = mysqli_query($koneksi, $query);

// Menyiapkan array kosong untuk menampung data hasil query
$data = array();

// Melakukan perulangan untuk mengambil setiap baris data hasil query
while ($row = mysqli_fetch_assoc($result)) {

    // Menambahkan setiap baris data ke dalam array $data
    $data[] = $row;
}

// Mengubah array $data menjadi format JSON dan menampilkannya
echo json_encode($data);
?>
