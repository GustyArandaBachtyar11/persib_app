<?php
// Menyimpan nama host database (biasanya localhost untuk XAMPP)
$host = "localhost";

// Menyimpan username database (default XAMPP: root)
$user = "root";

// Menyimpan password database (default XAMPP: kosong)
$pass = "";

// Menyimpan nama database yang digunakan
$db   = "persib_app";

// Membuat koneksi ke database MySQL menggunakan mysqli
$koneksi = mysqli_connect($host, $user, $pass, $db);

// Mengecek apakah koneksi berhasil atau gagal
if (!$koneksi) {

    // Jika koneksi gagal, hentikan program dan tampilkan pesan error
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
