<?php
// Memanggil file koneksi database
include "koneksi.php";

// Mengambil data lawan yang dikirim dari form / request POST
$lawan = $_POST['lawan'];

// Mengambil data tanggal pertandingan dari request POST
$tanggal = $_POST['tanggal'];

// Mengambil data nama stadion dari request POST
$stadion = $_POST['stadion'];

// Mengambil data jam pertandingan dari request POST
$jam = $_POST['jam'];

// Menyusun query SQL untuk menambahkan data ke tabel jadwal
$query = "INSERT INTO jadwal (lawan, tanggal, stadion, jam) 
          VALUES ('$lawan', '$tanggal', '$stadion', '$jam')";

// Mengeksekusi query INSERT ke database
if (mysqli_query($koneksi, $query)) {

    // Jika query berhasil, kirim response JSON status sukses
    echo json_encode(["status" => "success"]);

} else {

    // Jika query gagal, kirim response JSON status error
    echo json_encode(["status" => "error"]);
}
?>
