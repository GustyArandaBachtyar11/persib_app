<?php
// Menghubungkan file koneksi ke database
include "koneksi.php";

// Mengambil data id jadwal yang dikirim melalui metode POST
$id = $_POST['id'];

// Membuat query SQL untuk menghapus data jadwal berdasarkan id
$query = "DELETE FROM jadwal WHERE id='$id'";

// Menjalankan query hapus ke database
if (mysqli_query($koneksi, $query)) {

    // Jika query berhasil dijalankan, kirim response JSON status success
    echo json_encode(["status" => "success"]);

} else {

    // Jika query gagal dijalankan, kirim response JSON status error
    echo json_encode(["status" => "error"]);
}
?>
