<?php
// Menghubungkan file koneksi database
include "koneksi.php";

// Mengambil data ID jadwal yang dikirim dari request POST
$id = $_POST['id'];

// Mengambil data nama lawan dari request POST
$lawan = $_POST['lawan'];

// Mengambil data tanggal pertandingan dari request POST
$tanggal = $_POST['tanggal'];

// Mengambil data stadion dari request POST
$stadion = $_POST['stadion'];

// Mengambil data jam pertandingan dari request POST
$jam = $_POST['jam'];

// Membuat query SQL untuk mengupdate data jadwal berdasarkan ID
$query = "UPDATE jadwal 
          SET lawan='$lawan', 
              tanggal='$tanggal', 
              stadion='$stadion', 
              jam='$jam' 
          WHERE id='$id'";

// Mengeksekusi query update ke database
if (mysqli_query($koneksi, $query)) {

    // Jika query berhasil dijalankan, kirim response JSON status sukses
    echo json_encode(["status" => "success"]);

} else {

    // Jika query gagal dijalankan, kirim response JSON status error
    echo json_encode(["status" => "error"]);
}
?>
